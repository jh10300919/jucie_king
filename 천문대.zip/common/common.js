$(()=>{
    // 햄버거버튼
    $('.big_ham').click(function(){
        $('.big_ham').toggleClass('on')
    })

    // 슬라이드
    $(()=>{
        let wd = $('.slide>li').width()+120
        let intv = setInterval(function(){ nextAni()},3000)

        function nextAni(){
            $('.slide').not(':animated').animate({
                'margin-left':-wd+'px'
            },700,function(){
                $('.slide>li').eq(0).appendTo($('.slide'))
                $('.slide').css({marginLeft:'-120px'})
                $('.dot_con span').eq(0).appendTo($('.dot_con'))
                $('.dot_con span').removeClass('on')
                $('.dot_con span').eq(1).addClass('on')

            })
        }
        function prevAni(){
            $('.dot_con span').eq(-1).prependTo($('.dot_con'))
                $('.dot_con span').removeClass('on')
                $('.dot_con span').eq(1).addClass('on')

            $('.slide>li').eq(-1).prependTo($('.slide'))
            $('.slide').css('margin-left',-wd+'px')
            $('.slide').not(':animated').animate({
                'margin-left':'-120px'
            },700)
        }

        function numAni(num){
            for(let x = 0; x < num+2; x++){
                $('.dot_con span').eq(0).appendTo($('.dot_con'))
                $('.slide>li').eq(0).appendTo($('.slide'))
            }
            nextAni()
        }

        $('.dot_con span').click(function(){
            let btnNum = $(this).index();
            clearInterval(intv)
            numAni(btnNum)
            intv = setInterval(function(){
                nextAni()}
                ,3000)
            })
            
        })

        $('.next').click(function(){
            clearInterval(intv)
            nextAni();
            intv = setInterval(function(){ nextAni()},3000)
        })

        $('.prev').click(function(){
            clearInterval(intv)
            prevAni()
            intv = setInterval(function(){ nextAni()},3000)
        })


    })